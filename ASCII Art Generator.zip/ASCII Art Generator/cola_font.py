#cola font
#assigning ascii art(string) of each letter to a variable

def cola():
    A='''
             /\   
         _  / |   
        (  /  |  .
         `/.__|_.'
     .:' /    |   
    (__.'     `-' 
     '''
    B='''
       .-.       
      (_) )-.    
        .: __)   
       .:'   `.  
       :'      ) 
    (_/  `----'  
     '''
     
    C='''
      .-._   .-._.
    .: (_)`-'     
    ::            
    ::   _        
    `: .; )       
      `--'        
    '''
    D='''
       .-.       
      (_) )-.    
        .:   \   
       .:'    \  
     .-:.      ) 
    (_/  `----'  
    '''
    
    E='''
               .- 
       .;;;.`-'   
      ;;  (_)     
      .;;; .-.    
     ;;  .;  ;    
     `;.___.'     
    '''
    
    F='''
       .-._.;;;' 
      (_).;      
        .:--.    
       .:'       
     .-:         
    (_/          
    '''
    
    G='''
               .-.
        .;;.`-'   
       ;; (_;     
      ;;          
     ;;    `;;'   
     `;.___.'     
    '''
    
    H='''
         `;   .'  
        _ `; ; (  
       (  ;' ;  ) 
        `.;__;.'  
     .  .:'  `:.  
    (_.'       `: 
    '''
    
    I='''
           .;;;;. 
          ' .;'  `
           .;'    
          .;'     
         .;'      
     .;;;;;;;;;'  
    '''
    
    J='''
             .;;; 
              .;' 
             .;'  
    .-.     .;'   
    `.     .;     
      `;;;;;;'    
    '''
    K='''
        .-.       
       (_).)   .' 
         .:   ;   
        -:'..'    
     .  :' `:     
    (_.'     `.'  
    '''
    
    L='''
             .-.  
           ;' (_) 
         .:'      
        .:'       
      .-:.    .-. 
     (_/ `;._.    
    '''
    
    M='''
          .-.     
           .;|/:  
          .;   :  
         .;    :  
     .:'.;     :  
    (__.'      `. 
    '''
    
    N='''
          .-.     
            ;  :  
          .;:  :  
         .;' \ :  
     .:'.;    \:  
    (__.'      `. 
    '''
    
    O='''
                  
       .;;.    .- 
      ;;  `;`-'   
     ;;    :.     
    ;;     ;'     
    `;.__.'       
    '''
    
    P='''
       .-.      
      (_) )-.   
        .:   \  
       .:'    ) 
     .-:. `--'  
    (_/         
    '''
    
    Q='''
               
       .;;.    
      ;;  `;   
     ;;    :   
    ;;  `. ;   
    `;.__.:._. 
    '''
    
    R='''
       .-.        
      (_) )-.     
        .:   \    
       .::.   )   
     .-:. `:-'    
    (_/     `:._. 
    '''
    
    S='''
               .-.
       .;;;.`-'   
      ;;  (_)     
      `;;;.       
      _   `:      
     (_.;;;'      
    '''
    
    T='''
     .-.;;;;;;' 
    (_)  .;     
         :      
       .:'      
     .-:._      
    (_/  `-     
    '''
    
    U='''
                 
       .;.   .-. 
        ;;   ;   
       ;;    :   
      ;;     ;   
      `;.__.:    
    '''
    
    V='''
                  
    .;.       .-. 
     `;     .'    
      ;;  .'      
     ;;  ;        
     `;.'         
    '''
    
    W='''
                  
    .;.       .-. 
      `;     ;'   
       ;;    ;    
      ;;  ;  ;;   
      `;.' `.;'   
    '''
    
    X='''
                 
     .-.     .-. 
    (   `. .'    
     `-' ;;      
         ;;   .- 
     .-._;`._;   
    '''
    
    Y='''
    .             
        .:.   .-. 
         ;;   :   
         ;    ;   
     .:' `._.:    
    (__.-.;'      
    '''
    
    Z='''
    -.          
    `-.;;;.     
          ;;    
       .;;;'    
      :'   .-.  
      `;;;.-._) 
    '''
    #variables for the stylized (outer design/banner) for the special words
    
    no1="""
    ~~~~~~~~~*******ຄ⃛ HappyஐHappy⃛**(✿ŎヮŎ)*******(◕◡◕🌸)******~~~~~~~~~
    """
    no2="""
    ~~~~~~~~~~~~~~~********✧(๑✪д✪)۶ㅂ٩(✪д✪๑)✧^^^✺◟(⩹Д⩺)◞✺^^^✺◟(⩹Д⩺)◞✺~~~~~~~~~~~~~~~
    """
    
    no3="""
    ~~~~~~~~*******😒^^^(*ﾟ∀ﾟ)っ［.+:｡★Good night★.+:｡］^^^😒******~~~~~~~~
    """
    
    no4="""
    ~~~~~~~~~~~~~~~~~************🌄(ᴗ◞ ᴗ)☼^（⊃曲｀）。o○Ｇｏｏｄｍｏｒｎｉｎｇ^(ง ͠° ͟⏰ ͡°)ง🌄************~~~~~~~~~~~~~~~~~
    """
    
    no5="""
    ~~~~***☆⌒(*^-ﾟ)ﾉ~♪see you again♪~ヾ(ﾟ-^*)⌒☆***~~~
    """
    
    
    
    letters={
    '1':no1.splitlines(),
    '2':no2.splitlines(),
    '3':no3.splitlines(),
    '4':no4.splitlines(),
    '5':no5.splitlines(),
    
    'a': A.splitlines(),
    'b': B.splitlines(),
    'c': C.splitlines(),
    'd': D.splitlines(),
    'e': E.splitlines(),
    'f': F.splitlines(),
    'g': G.splitlines(),
    'h': H.splitlines(),
    'i': I.splitlines(),
    'j': J.splitlines(),
    'k': K.splitlines(),
    'l': L.splitlines(),
    'm': M.splitlines(),
    'n': N.splitlines(),
    'o': O.splitlines(),
    'p': P.splitlines(),
    'q': Q.splitlines(),
    'r': R.splitlines(),
    's': S.splitlines(),
    't': T.splitlines(),
    'u': U.splitlines(),
    'v': V.splitlines(),
    'w': W.splitlines(),
    'x': X.splitlines(),
    'y': Y.splitlines(),
    'z': Z.splitlines()
        }
    
    
    
    
    
    #making the word into a list so i can use each letter to call a key in the dictionary. it also automatically adds a comma to separate each letter
    words=input('enter word- ')
    #convert small letter to big letters

    #is user keys in capital words it converts to lower cast as variables and keys are in lower case letters
    word=words.lower()
    word_broken = list(word)
    
    #assigning the key value for each deco(decoration) to a variable
    deco1='1'
    deco2='2'
    deco3='3'
    deco4='4'
    deco5='5'
    
    
    if word=='happy':
         #adding the border to the word and printing the grinning face emoji
        for letter in deco1:
            print("\n".join(letters[letter]) + "\n")
        
        #to show just the ascii art of the word
        for row in range(7):
            #to print the letters horizontally
            #goes through each row(section) of the ascii art 7 times in letter
            for letter in word_broken:
                #gets the ascii version of the letter but only prints it horizonally
                print(letters[letter][row], end=" ")
            #prints each row vertcally instead of horizontally 
            print(" ")
             #adding the border to the word and printing the grinning face emoji
        for letter in deco1:
            print("\n".join(letters[letter]) + "\n")
            
    elif word=='cheers':
         #adding the border to the word and printing the grinning face emoji
        for letter in deco2:
            print("\n".join(letters[letter]) + "\n")
        
        #to show just the ascii art of the word
        for row in range(7):
            #to print the letters horizontally
            #goes through each row(section) of the ascii art 7 times in letter
            for letter in word_broken:
                #gets the ascii version of the letter but only prints it horizonally
                print(letters[letter][row], end=" ")
            #prints each row vertcally instead of horizontally 
            print(" ")
             #adding the border to the word and printing the grinning face emoji
        for letter in deco2:
            print("\n".join(letters[letter]) + "\n")
                    
    elif word=='night':
         #adding the border to the word and printing the grinning face emoji
        for letter in deco3:
            print("\n".join(letters[letter]) + "\n")
        
        #to show just the ascii art of the word
        for row in range(7):
            #to print the letters horizontally
            #goes through each row(section) of the ascii art 7 times in letter
            for letter in word_broken:
                #gets the ascii version of the letter but only prints it horizonally
                print(letters[letter][row], end=" ")
            #prints each row vertcally instead of horizontally 
            print(" ")
             #adding the border to the word and printing the grinning face emoji
        for letter in deco3:
            print("\n".join(letters[letter]) + "\n")
    
    elif word=='morning':
         #adding the border to the word and printing the grinning face emoji
        for letter in deco4:
            print("\n".join(letters[letter]) + "\n")
        
        #to show just the ascii art of the word
        for row in range(7):
            #to print the letters horizontally
            #goes through each row(section) of the ascii art 7 times in letter
            for letter in word_broken:
                #gets the ascii version of the letter but only prints it horizonally
                print(letters[letter][row], end=" ")
            #prints each row vertcally instead of horizontally 
            print(" ")
             #adding the border to the word and printing the grinning face emoji
        for letter in deco4:
            print("\n".join(letters[letter]) + "\n")
            
    elif word=='bye':
         #adding the border to the word and printing the grinning face emoji
        for letter in deco5:
            print("\n".join(letters[letter]) + "\n")
        
        #to show just the ascii art of the word
        for row in range(7):
            #to print the letters horizontally
            #goes through each row(section) of the ascii art 7 times in letter
            for letter in word_broken:
                #gets the ascii version of the letter but only prints it horizonally
                print(letters[letter][row], end=" ")
            #prints each row vertcally instead of horizontally 
            print(" ")
             #adding the border to the word and printing the grinning face emoji
        for letter in deco5:
            print("\n".join(letters[letter]) + "\n")        
            
            
    else:
        for row in range(8):
    #to print the letters horizontally
    #goes through each row(section) of the ascii art 7 times in letter
           for letter in word_broken:
    #gets the ascii version of the letter but only prints it horizonally
                print(letters[letter][row], end=" ")
    #prints each row vertcally instead of horizontally 
           print(" ")
    
    
    
    
    



































































































































