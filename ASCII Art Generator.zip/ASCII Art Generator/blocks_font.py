#blocks font

def blocks():    
    a='''
     .----------------. 
    | .--------------. |
    | |      __      | |
    | |     /  \     | |
    | |    / /\ \    | |
    | |   / ____ \   | |
    | | _/ /    \ \_ | |
    | ||____|  |____|| |
    | |              | |
    | '--------------' |
     '----------------' 
     '''
    b='''
     .----------------. 
    | .--------------. |
    | |   ______     | |
    | |  |_   _ \    | |
    | |    | |_) |   | |
    | |    |  __'.   | |
    | |   _| |__) |  | |
    | |  |_______/   | |
    | |              | |
    | '--------------' |
     '----------------' 
    '''
    
    c='''
     .----------------. 
    | .--------------. |
    | |     ______   | |
    | |   .' ___  |  | |
    | |  / .'   \_|  | |
    | |  | |         | |
    | |  \ `.___.'\  | |
    | |   `._____.'  | |
    | |              | |
    | '--------------' |
     '----------------' 
    '''
    
    d='''
     .----------------. 
    | .--------------. |
    | |  ________    | |
    | | |_   ___ `.  | |
    | |   | |   `. \ | |
    | |   | |    | | | |
    | |  _| |___.' / | |
    | | |________.'  | |
    | |              | |
    | '--------------' |
     '----------------' 
    '''
    
    e='''
     .----------------. 
    | .--------------. |
    | |  _________   | |
    | | |_   ___  |  | |
    | |   | |_  \_|  | |
    | |   |  _|  _   | |
    | |  _| |___/ |  | |
    | | |_________|  | |
    | |              | |
    | '--------------' |
     '----------------' 
    '''
    
    f='''
     .----------------. 
    | .--------------. |
    | |  _________   | |
    | | |_   ___  |  | |
    | |   | |_  \_|  | |
    | |   |  _|      | |
    | |  _| |_       | |
    | | |_____|      | |
    | |              | |
    | '--------------' |
     '----------------' 
    '''
    
    g='''
     .----------------. 
    | .--------------. |
    | |    ______    | |
    | |  .' ___  |   | |
    | | / .'   \_|   | |
    | | | |    ____  | |
    | | \ `.___]  _| | |
    | |  `._____.'   | |
    | |              | |
    | '--------------' |
     '----------------' 
    '''
    
    h='''
     .----------------. 
    | .--------------. |
    | |  ____  ____  | |
    | | |_   ||   _| | |
    | |   | |__| |   | |
    | |   |  __  |   | |
    | |  _| |  | |_  | |
    | | |____||____| | |
    | |              | |
    | '--------------' |
     '----------------' 
    '''
    
    i='''
     .----------------. 
    | .--------------. |
    | |     _____    | |
    | |    |_   _|   | |
    | |      | |     | |
    | |      | |     | |
    | |     _| |_    | |
    | |    |_____|   | |
    | |              | |
    | '--------------' |
     '----------------' 
    '''
    
    j='''
     .----------------. 
    | .--------------. |
    | |     _____    | |
    | |    |_   _|   | |
    | |      | |     | |
    | |   _  | |     | |
    | |  | |_' |     | |
    | |  `.___.'     | |
    | |              | |
    | '--------------' |
     '----------------' 
    '''
    
    k='''
     .----------------. 
    | .--------------. |
    | |  ___  ____   | |
    | | |_  ||_  _|  | |
    | |   | |_/ /    | |
    | |   |  __'.    | |
    | |  _| |  \ \_  | |
    | | |____||____| | |
    | |              | |
    | '--------------' |
     '----------------' 
    '''
    
    l='''
     .----------------. 
    | .--------------. |
    | |   _____      | |
    | |  |_   _|     | |
    | |    | |       | |
    | |    | |   _   | |
    | |   _| |__/ |  | |
    | |  |________|  | |
    | |              | |
    | '--------------' |
     '----------------' 
    '''
    
    m='''
     .----------------. 
    | .--------------. |
    | | ____    ____ | |
    | ||_   \  /   _|| |
    | |  |   \/   |  | |
    | |  | |\  /| |  | |
    | | _| |_\/_| |_ | |
    | ||_____||_____|| |
    | |              | |
    | '--------------' |
     '----------------' 
    '''
    
    n='''
     .-----------------.
    | .--------------. |
    | | ____  _____  | |
    | ||_   \|_   _| | |
    | |  |   \ | |   | |
    | |  | |\ \| |   | |
    | | _| |_\   |_  | |
    | ||_____|\____| | |
    | |              | |
    | '--------------' |
     '----------------' 
    '''
    
    o='''
     .----------------. 
    | .--------------. |
    | |     ____     | |
    | |   .'    `.   | |
    | |  /  .--.  \  | |
    | |  | |    | |  | |
    | |  \  `--'  /  | |
    | |   `.____.'   | |
    | |              | |
    | '--------------' |
     '----------------' 
    '''
    
    p='''
     .----------------. 
    | .--------------. |
    | |   ______     | |
    | |  |_   __ \   | |
    | |    | |__) |  | |
    | |    |  ___/   | |
    | |   _| |_      | |
    | |  |_____|     | |
    | |              | |
    | '--------------' |
     '----------------' 
    '''
    
    q='''
     .----------------. 
    | .--------------. |
    | |    ___       | |
    | |  .'   '.     | |
    | | /  .-.  \    | |
    | | | |   | |    | |
    | | \  `-'  \_   | |
    | |  `.___.\__|  | |
    | |              | |
    | '--------------' |
     '----------------' 
    '''
    
    r='''
     .----------------. 
    | .--------------. |
    | |  _______     | |
    | | |_   __ \    | |
    | |   | |__) |   | |
    | |   |  __ /    | |
    | |  _| |  \ \_  | |
    | | |____| |___| | |
    | |              | |
    | '--------------' |
     '----------------' 
    '''
    
    s='''
     .----------------. 
    | .--------------. |
    | |    _______   | |
    | |   /  ___  |  | |
    | |  |  (__ \_|  | |
    | |   '.___`-.   | |
    | |  |`\____) |  | |
    | |  |_______.'  | |
    | |              | |
    | '--------------' |
     '----------------' 
    '''
    
    t='''
     .----------------. 
    | .--------------. |
    | |  _________   | |
    | | |  _   _  |  | |
    | | |_/ | | \_|  | |
    | |     | |      | |
    | |    _| |_     | |
    | |   |_____|    | |
    | |              | |
    | '--------------' |
     '----------------' 
    '''
    
    u='''
     .----------------. 
    | .--------------. |
    | | _____  _____ | |
    | ||_   _||_   _|| |
    | |  | |    | |  | |
    | |  | '    ' |  | |
    | |   \ `--' /   | |
    | |    `.__.'    | |
    | |              | |
    | '--------------' |
     '----------------' 
    '''
    
    v='''
     .----------------. 
    | .--------------. |
    | | ____   ____  | |
    | ||_  _| |_  _| | |
    | |  \ \   / /   | |
    | |   \ \ / /    | |
    | |    \ ' /     | |
    | |     \_/      | |
    | |              | |
    | '--------------' |
     '----------------' 
    '''
    
    w='''
     .----------------. 
    | .--------------. |
    | | _____  _____ | |
    | ||_   _||_   _|| |
    | |  | | /\ | |  | |
    | |  | |/  \| |  | |
    | |  |   /\   |  | |
    | |  |__/  \__|  | |
    | |              | |
    | '--------------' |
     '----------------' 
    '''
    
    x='''
     .----------------. 
    | .--------------. |
    | |  ____  ____  | |
    | | |_  _||_  _| | |
    | |   \ \  / /   | |
    | |    > `' <    | |
    | |  _/ /'`\ \_  | |
    | | |____||____| | |
    | |              | |
    | '--------------' |
     '----------------' 
    '''
    
    y='''
     .----------------. 
    | .--------------. |
    | |  ____  ____  | |
    | | |_  _||_  _| | |
    | |   \ \  / /   | |
    | |    \ \/ /    | |
    | |    _|  |_    | |
    | |   |______|   | |
    | |              | |
    | '--------------' |
     '----------------' 
    '''
    
    z='''
     .----------------. 
    | .--------------. |
    | |   ________   | |
    | |  |  __   _|  | |
    | |  |_/  / /    | |
    | |     .'.' _   | |
    | |   _/ /__/ |  | |
    | |  |________|  | |
    | |              | |
    | '--------------' |
     '----------------' 
    '''
    #variables for the stylized (outer design/banner) for the special words
    no1="""
    -------*******◠‿◠   ¤‿¤  ( 。‿‿ 。) (｡✿‿✿) (✿‿✿｡) ( ╹‿╹。) (≧◡≦) (⌯⌅‿⌅)(✿◠‿◠) (◡‿◡✿)*******-------
    """
    no2="""
    --------******^^^^^^(づ｡◕‿‿◕｡)づ (☞ﾟ∀ﾟ)☞  （σ・з・）σ (~￣▽￣)~***∩^ω^∩ ( ๑´•ω•)۶” (๑ˇ3ˇ๑)  (ლ╹ɞ╹)ლ^^^^^^******-------.........   
      .                   
     . .      
      ...                        -*                           )   *
    \~~~~~/                                    )     *      (
     \   /               )        (                   (
      \ /                       (          )     (             )
       V                            (                (        (      *
       |                               )          H     )        )
       |                                         [ ]            (
      ---                                 (  *   |-|       *     )    (
                                          (      | |    .  
                                    )           /   \     .    ' .        *
                                   (           |_____|  '  .    .  
                                    )          | ___ |  \~~~/  ' .   (
                                           *   | \ / |   \_/  \~~~/   )
                                               | _Y_ |    |    \_/   (
                                               |-----|  __|__   |      *
                                               `-----`        _ |__
      
    """
    
    no3="""
      .                   
     . .      
      ...                        -*                           )   *
    \~~~~~/                                    )     *      (
     \   /               )        (                   (
      \ /                       (          )     (             )
       V                            (                (        (      *
       |                               )          H     )        )
       |                                         [ ]            (
      ---                                 (  *   |-|       *     )    (
                                          (      | |    .  
                                    )           /   \     .    ' .        *
                                   (           |_____|  '  .    .  
                                    )          | ___ |  \~~~/  ' .   (
                                           *   | \ / |   \_/  \~~~/   )
                                               | _Y_ |    |    \_/   (
                                               |-----|  __|__   |      *
                                               `-----`        _ |__
                                               
    -------*****^^^^^^(づ｡◕‿‿◕｡)づ (☞ﾟ∀ﾟ)☞  （σ・з・）σ (~￣▽￣)~***∩^ω^∩ ( ๑´•ω•)۶” (๑ˇ3ˇ๑)  (ლ╹ɞ╹)ლ^^^^^^*****--------.........                                          
    """
    no4="""
    ★　★　★　　　
    _____★█████★
    __★█████★
    _★█████★•★
    ★█████★•★•★ ★
    ★█████★•★•★•★
    _★█████★•★•★
    __★█████★•★
    _____★█████ ★
    _________★__★
    ____________★
    __________★
    
    (☪‿☪) (☪ε☪) (✺_✺ )  (∪｡∪)｡｡｡zzzZZ(☪‿☪) (☪ε☪) (✺_✺ )  (∪｡∪)｡｡｡zzzZZ(☪‿☪) (☪ε☪) (✺_✺ )  
    """
    no5="""
    (☪‿☪) (☪ε☪) (✺_✺ )  (∪｡∪)｡｡｡zzzZZ(☪‿☪) (☪ε☪) (✺_✺ )  (∪｡∪)｡｡｡zzzZZ(☪‿☪) (☪ε☪) (✺_✺ )  
                                                                                    ★　★　★　　　
    ___  ★█████★
    __★█████★
    _★█████★•★
    ★█████★•★•★ ★
    ★█████★•★•★•★
    _★█████★•★•★
    __★█████★•★
    _____★█████ ★
    _________★__★
    ____________★
    __________★
    """
    
    no6="""
       .
          \ | /
        '-.;;;.-'
       -==;;;;;==-
        .-';;;'-.
          / | \
            '
    ღƪ(ˆ◡ˆ)ʃ☼♥  ^^^*♥∗ღƪ(ˆ▽ˆ)ʃღƪ(ˆ◡ˆ)ʃ☼♥  ƪ(˘˛˘)ʃƪ(ˆ◡ˆ)ʃ   *♥∗ღƪ(ˆ▽ˆ)ʃღƪ(ˆ◡ˆ)ʃ☼♥  ƪ(˘˛˘)ʃƪ(ˆ◡ˆ)ʃ   *♥∗ღƪ(ˆ▽ˆ)ʃღƪ(ˆ◡ˆ)ʃ☼♥  ƪ(ˆ◡ˆ)ʃ   *♥∗ღƪ(ˆ▽ˆ)ʃ
    """
    
    no7="""
    ღƪ(ˆ◡ˆ)ʃ☼♥   ^^^ *♥∗ღƪ(ˆ▽ˆ)ʃღƪ(ˆ◡ˆ)ʃ☼♥  ƪ(˘˛˘)ʃƪ(ˆ◡ˆ)ʃ   *♥∗ღƪ(ˆ▽ˆ)ʃღƪ(ˆ◡ˆ)ʃ☼♥  ƪ(˘˛˘)ʃƪ(ˆ◡ˆ)ʃ   *♥∗ღƪ(ˆ▽ˆ)ʃღƪ(ˆ◡ˆ)ʃ☼♥  ƪ(ˆ◡ˆ)ʃ   *♥∗ღƪ(ˆ▽ˆ)ʃ
       .
          \ | /
        '-.;;;.-'
       -==;;;;;==-
        .-';;;'-.
          / | \
            '
    """
    
    no8="""
    -----＼(°o°；）*****｡.:*･ﾟβyё☆.｡.:*･ﾟ☆･ﾟ☆βyё.｡*****(∗ ･‿･)ﾉ゛-----
    """
    



    
    
    letters={
    '1':no1.splitlines(),
    '2':no2.splitlines(),
    '3':no3.splitlines(),
    '4':no4.splitlines(),
    '5':no5.splitlines(),
    '6':no6.splitlines(),
    '7':no7.splitlines(),
    '8':no8.splitlines(),
    
    'a': a.splitlines(),
    'b': b.splitlines(),
    'c': c.splitlines(),
    'd': d.splitlines(),
    'e': e.splitlines(),
    'f': f.splitlines(),
    'g': g.splitlines(),
    'h': h.splitlines(),
    'i': i.splitlines(),
    'j': j.splitlines(),
    'k': k.splitlines(),
    'l': l.splitlines(),
    'm': m.splitlines(),
    'n': n.splitlines(),
    'o': o.splitlines(),
    'p': p.splitlines(),
    'q': q.splitlines(),
    'r': r.splitlines(),
    's': s.splitlines(),
    't': t.splitlines(),
    'u': u.splitlines(),
    'v': v.splitlines(),
    'w': w.splitlines(),
    'x': x.splitlines(),
    'y': y.splitlines(),
    'z': z.splitlines()
        }
    
    
    #making the word into a list so i can use each letter to call a key in the dictionary. it also automatically adds a comma to separate each letter
    words=input('enter word- ')

    #is user keys in capital words it converts to lower cast as variables and keys are in lower case letters
    word=words.lower()
    word_broken = list(word)
    
    #assigning the key value for each deco(decoration) to a variable
    deco1='1'
    deco2='2'
    deco3='3'
    deco4='4'
    deco5='5'
    deco6='6'
    deco7='7'
    deco8='8'

    
    
    if word=='happy':
         #adding the border to the word and printing the grinning face emoji
        for letter in deco1:
            print("\n".join(letters[letter]) + "\n")
        
        #to show just the ascii art of the word
        for row in range(12):
            #to print the letters horizontally
            #goes through each row(section) of the ascii art 12 times in letter
            for letter in word_broken:
                #gets the ascii version of the letter but only prints it horizonally
                print(letters[letter][row], end=" ")
            #prints each row vertcally instead of horizontally 
            print(" ")
             #adding the border to the word and printing the grinning face emoji
        for letter in deco1:
            print("\n".join(letters[letter]) + "\n")
            
    elif word=='cheers':
         #adding the border to the word and printing the grinning face emoji
        for letter in deco3:
            print("\n".join(letters[letter]) + "\n")
        
        #to show just the ascii art of the word
        for row in range(12):
            #to print the letters horizontally
            #goes through each row(section) of the ascii art 12 times in letter
            for letter in word_broken:
                #gets the ascii version of the letter but only prints it horizonally
                print(letters[letter][row], end=" ")
            #prints each row vertcally instead of horizontally 
            print(" ")
             #adding the border to the word and printing the grinning face emoji
        for letter in deco2:
            print("\n".join(letters[letter]) + "\n")
                    
    elif word=='night':
         #adding the border to the word and printing the grinning face emoji
        for letter in deco4:
            print("\n".join(letters[letter]) + "\n")
        
        #to show just the ascii art of the word
        for row in range(12):
            #to print the letters horizontally
            #goes through each row(section) of the ascii art 12 times in letter
            for letter in word_broken:
                #gets the ascii version of the letter but only prints it horizonally
                print(letters[letter][row], end=" ")
            #prints each row vertcally instead of horizontally 
            print(" ")
             #adding the border to the word and printing the grinning face emoji
        for letter in deco5:
            print("\n".join(letters[letter]) + "\n")
    
    elif word=='morning':
         #adding the border to the word and printing the grinning face emoji
        for letter in deco6:
            print("\n".join(letters[letter]) + "\n")
        
        #to show just the ascii art of the word
        for row in range(12):
            #to print the letters horizontally
            #goes through each row(section) of the ascii art 12 times in letter
            for letter in word_broken:
                #gets the ascii version of the letter but only prints it horizonally
                print(letters[letter][row], end=" ")
            #prints each row vertcally instead of horizontally 
            print(" ")
             #adding the border to the word and printing the grinning face emoji
        for letter in deco7:
            print("\n".join(letters[letter]) + "\n")
            
    elif word=='bye':
         #adding the border to the word and printing the grinning face emoji
        for letter in deco8:
            print("\n".join(letters[letter]) + "\n")
        
        #to show just the ascii art of the word
        for row in range(12):
            #to print the letters horizontally
            #goes through each row(section) of the ascii art 12 times in letter
            for letter in word_broken:
                #gets the ascii version of the letter but only prints it horizonally
                print(letters[letter][row], end=" ")
            #prints each row vertcally instead of horizontally 
            print(" ")
             #adding the border to the word and printing the grinning face emoji
        for letter in deco8:
            print("\n".join(letters[letter]) + "\n")        
            
            
    else:
        for row in range(12):
    #to print the letters horizontally
    #goes through each row(section) of the ascii art 12 times in letter
           for letter in word_broken:
    #gets the ascii version of the letter but only prints it horizonally
                print(letters[letter][row], end=" ")
    #prints each row vertcally instead of horizontally 
           print(" ")





























































































































































