def elite():
    
    
    a="""
     ▄▄▄· 
    ▐█ ▀█ 
    ▄█▀▀█ 
    ▐█ ▪▐▌
     ▀  ▀ 
         """
          
         
    b="""
     ▄▄▄▄· 
    ▐█ ▀█▪
     █▀▀█▄
    ██▄▪▐█
    ·▀▀▀▀ 
           """  
        
    c="""
     ▄▄· 
    ▐█ ▌▪
    ██ ▄▄
    ▐███▌
    ·▀▀▀ 
            """
    
    d="""
    ·▄▄▄▄  
    ██▪ ██ 
    ▐█· ▐█▌
    ██. ██ 
    ▀▀▀▀▀• 
            """
    e='''
    ▄▄▄ .
    ▀▄.▀·
    ▐▀▀▪▄
    ▐█▄▄▌
     ▀▀▀ '''
     
    f='''
    ·▄▄▄
    ▐▄▄·
    ██▪ 
    ██▌.
    ▀▀▀ 
    '''
    g='''
     ▄▄ • 
    ▐█ ▀ ▪
    ▄█ ▀█▄
    ▐█▄▪▐█
    ·▀▀▀▀ '''
    h='''
     ▄ .▄
    ██▪▐█
    ██▀▐█
    ██▌▐▀
    ▀▀▀ ·'''
    i='''
    ▪  
    ██ 
    ▐█·
    ▐█▌
    ▀▀▀'''
    j='''
     ▐▄▄▄
      ·██
    ▪▄ ██
    ▐▌▐█▌
     ▀▀▀•'''
    k='''
    ▄ •▄ 
    █▌▄▌▪
    ▐▀▀▄·
    ▐█.█▌
    ·▀  ▀'''
    l='''
    ▄▄▌  
    ██•  
    ██▪  
    ▐█▌▐▌
    .▀▀▀ '''
    m='''
    • ▌ ▄ ·. 
    ·██ ▐███▪
    ▐█ ▌▐▌▐█·
    ██ ██▌▐█▌
    ▀▀  █▪▀▀▀'''
    n='''
     ▐ ▄ 
    •█▌▐█
    ▐█▐▐▌
    ██▐█▌
    ▀▀ █▪'''
    o='''
          
    ▪     
     ▄█▀▄ 
    ▐█▌.▐▌
     ▀█▄▀▪'''
    p='''
     ▄▄▄·
    ▐█ ▄█
     ██▀·
    ▐█▪·•
    .▀   '''
    q='''
    .▄▄▄  
    ▐▀•▀█ 
    █▌·.█▌
    ▐█▪▄█·
    ·▀▀█. '''
    r='''
    ▄▄▄  
    ▀▄ █·
    ▐▀▀▄ 
    ▐█•█▌
    .▀  ▀'''
    s='''
    .▄▄ · 
    ▐█ ▀. 
    ▄▀▀▀█▄
    ▐█▄▪▐█
     ▀▀▀▀ '''
    t='''
    ▄▄▄▄▄
    •██  
     ▐█.▪
     ▐█▌·
     ▀▀▀ '''
    u='''
    ▄• ▄▌
    █▪██▌
    █▌▐█▌
    ▐█▄█▌
     ▀▀▀ '''
    v='''
     ▌ ▐·
    ▪█·█▌
    ▐█▐█•
     ███ 
    . ▀  '''
    w='''
    ▄▄▌ ▐ ▄▌
    ██· █▌▐█
    ██▪▐█▐▐▌
    ▐█▌██▐█▌
     ▀▀▀▀ ▀▪'''
    x='''
    ▐▄• ▄ 
     █▌█▌▪
     ·██· 
    ▪▐█·█▌
    •▀▀ ▀▀'''
    y='''
     ▄· ▄▌
    ▐█▪██▌
    ▐█▌▐█▪
     ▐█▀·.
      ▀ • '''
    z='''
    ·▄▄▄▄•
    ▪▀·.█▌
    ▄█▀▀▀•
    █▌▪▄█▀
    ·▀▀▀ •'''
    
    #variables for the stylized (outer design/banner) for the special words
    no1='''-------------********(◕‿◕✿)********-----------------

    ''' 
    no2='''---------------********~\(≧▽≦)/~********-------------------
    '''
    no3='''------------********(っ＾▿＾)۶🍸🌟🍺٩(˘◡˘ )********-------------
    '''
    no4='''---------------------********( -_-)>c[_]********-------------------------'''

    no5='''---------********Good ヽ(ｏ≧ω≦ｏ)ﾉ  ﾟ.:｡+ﾟ Morning********------------------'''
    
    no6='''★ * ♡ ─ ☆-- ｡♡ * ﾟ--｡-- ★ * ♡★ * ♡ ─ ☆-- ｡♡ * ﾟ--｡-- ★ '''
    
    no7=''' ★☆。.:*:･”ﾟ★βyё ヾ(o･(ェ)･o)ﾉβyё★｡.:*:･”☆★ '''
    
    #store the variable in dictionaries
    #use .splitlines() method to make string variables of letters into lists
    letters={
          '1':no1.splitlines(),
          '2':no2.splitlines(),
          '3':no3.splitlines(),
          '4':no4.splitlines(),
          '5':no5.splitlines(),
          '6':no6.splitlines(),
          '7':no7.splitlines(),
          
          'a':a.splitlines(),
          'b':b.splitlines(),
          'c':c.splitlines(),
          'd':d.splitlines(),
          'e':e.splitlines(),
          'f':f.splitlines(),
          'g':g.splitlines(),     
          'h':h.splitlines(),
          'i':i.splitlines(),
          'j':j.splitlines(),
          'k':k.splitlines(),
          'l':l.splitlines(),
          'm':m.splitlines(),         
          'n':n.splitlines(),
          'o':o.splitlines(),
          'p':p.splitlines(),
          'q':q.splitlines(),
          'r':r.splitlines(),
          's':s.splitlines(),     
          't':t.splitlines(),
          'u':u.splitlines(),
          'v':v.splitlines(),
          'w':w.splitlines(),
          'x':x.splitlines(),
          'y':y.splitlines(),       
          'z':z.splitlines()   
          }    
    
  
    #making the word into a list so i can use each letter to call a key in the dictionary. it also automatically adds a comma to separate each letter
    word=input('enter word- ')
    #if user keys in capital words it converts to lower cast as variables and keys are in lower case letters
    word=word.lower()
    #converts string to list so slicing is possible
    word_broken = list(word)
    
    #assigning the key value for each deco(decoration) to a variable
    #different stylized versions of the banner for each special word
    deco1='1'
    deco2='2'
    deco3='3'
    deco4='4'
    deco5='5'
    deco6='6'
    deco7='7'


  
    if word=='happy':
        #adding the border to the word and printing the grinning face emoji
        for letter in deco1:
            #if there is more that 1 row then it shows the banner vertically instead of horizontally
            print("".join(letters[letter]),"\U0001F601")        
        for row in range(6):
            #goes through each row(section) of the ascii art 6 times in letter
            for letter in word_broken:
                #gets the ascii version of the letter but only prints it horizonally
                print(letters[letter][row], end=" ")
            #prints each row vertcally instead of horizontally 
            print(" ")  
        #adding the border to the word
        for letter in deco1:
            #''\n'' is there to let there be an empty row at the bottom of the word so there is space between border and ascii art
            #if there is more that 1 row then it shows the banner vertically instead of horizontally            
            print("\n"+"".join(letters[letter]),"\U0001F601")   
            
    elif word=='cheers':
        #adding the border to the word and printing the grinning face emoji
        for letter in deco2:
            print("".join(letters[letter]))        
        for row in range(6):
            #goes through each row(section) of the ascii art 6 times in letter
            for letter in word_broken:
                #gets the ascii version of the letter but only prints it horizonally
                print(letters[letter][row], end=" ")
            #prints each row vertcally instead of horizontally 
            print(" ")  
        #adding the border to the word
        for letter in deco3:
            #''\n'' is there to let there be an empty row at the bottom of the word so there is space between border and ascii art
            print("\n"+"".join(letters[letter]))   
                    
    elif word=='morning':
        for letter in deco4:
            print("".join(letters[letter]))        
        for row in range(6):
            #goes through each row(section) of the ascii art 6 times in letter
            for letter in word_broken:
                #gets the ascii version of the letter but only prints it horizonally
                print(letters[letter][row], end=" ")
            #prints each row vertcally instead of horizontally 
            print(" ")  
        #adding the border to the word
        for letter in deco5:
            #''\n'' is there to let there be an empty row at the bottom of the word so there is space between border and ascii art
            print("\n"+"".join(letters[letter])) 
            
    elif word=='night':
        for letter in deco6:
            print("".join(letters[letter]))        
        for row in range(6):
            #goes through each row(section) of the ascii art 6 times in letter
            for letter in word_broken:
                #gets the ascii version of the letter but only prints it horizonally
                print(letters[letter][row], end=" ")
            #prints each row vertcally instead of horizontally 
            print(" ")  
        #adding the border to the word
        for letter in deco6:
            #''\n'' is there to let there be an empty row at the bottom of the word so there is space between border and ascii art
            print("\n"+"".join(letters[letter])) 
                                       
    elif word=='bye':
        for letter in deco7:
            print("".join(letters[letter]))        
        for row in range(6):
            #goes through each row(section) of the ascii art 6 times in letter
            for letter in word_broken:
                #gets the ascii version of the letter but only prints it horizonally
                print(letters[letter][row], end=" ")
            #prints each row vertcally instead of horizontally 
            print(" ")  
        #adding the border to the word
        for letter in deco7:
            #''\n'' is there to let there be an empty row at the bottom of the word so there is space between border and ascii art
            print("\n"+"".join(letters[letter])) 
                                               
            
    else:
        #to print the letters horizontally
        #goes through each row(section) of the ascii art 6 times in letter
        for row in range(6):
            #goes through 
            for letter in word_broken:
                #gets the ascii version of the letter but only prints it horizonally
                print(letters[letter][row], end=" ")
            #prints each row vertcally instead of horizontally 
            print(" ")
     
 
        
        
        
        

