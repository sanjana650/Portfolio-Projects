from elite_font import elite
from cola_font import cola
from blocks_font import blocks

menu="""
|PLEASE SELECT ONE OF THE FONTS|

1) For blocks font, key in 'blocks'

2) For elite font, key in 'elite'

3) For cola font, key in 'cola'

TO EXIT KEY IN 'Q' OR 'q'

            |THE SPECIAL WORDS|
 “Happy”, “Cheers”, “Morning”, “Night”, “Bye”

"""

start=True

while (start):
    cmd=input('ENTER A COMMAND- ')
    if cmd=='m' or cmd=='M':
        print(menu)
        
    elif cmd=='elite':
        elite()
    
    elif cmd=='cola':
        cola()
        
    elif cmd=='blocks':
        blocks()

    elif cmd=='q' or cmd=='Q':
        break
    else:
        print('key in correct command')